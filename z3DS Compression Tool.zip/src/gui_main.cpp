// -------------------------------------------------------------
// Modern Visual-Studio Dark Theme GUI for Z3DS Compressor
// -------------------------------------------------------------
// Pure Win32, no dependencies, DPI-aware, dark theme
// -------------------------------------------------------------

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commctrl.h>
#include <shlwapi.h>
#include <shellapi.h>
#include <string>
#include <thread>

#include "frontend_common.h"
#include "z3ds_compression.h"

#pragma comment(lib, "Comctl32.lib")
#pragma comment(lib, "Shlwapi.lib")

// -------------------------------------------------------------
//  DARK THEME COLORS (Visual Studio style)
// -------------------------------------------------------------
constexpr COLORREF CLR_BG       = RGB(30,30,30);
constexpr COLORREF CLR_PANEL    = RGB(45,45,48);
constexpr COLORREF CLR_EDITBG   = RGB(37,37,38);
constexpr COLORREF CLR_TEXT     = RGB(220,220,220);
constexpr COLORREF CLR_BORDER   = RGB(60,60,60);
constexpr COLORREF CLR_BTN      = RGB(63,63,70);
constexpr COLORREF CLR_BTN_HOVER= RGB(72,72,80);

// -------------------------------------------------------------
HFONT g_font = nullptr;

// Global handles
HWND hInput, hOutput, hBrowseIn, hBrowseOut;
HWND hFrameBytes, hLevel, hThreads;
HWND hChkRecursive, hChkDelete, hChkBatch, hChkDecompress;
HWND hStartBtn, hLog, hClearBtn;

// -------------------------------------------------------------
// Set control font
// -------------------------------------------------------------
void ApplyFont(HWND h)
{
    SendMessageW(h, WM_SETFONT, (WPARAM)g_font, TRUE);
}

// -------------------------------------------------------------
// Dark theme painting helper
// -------------------------------------------------------------
void PaintControl(HDC hdc, RECT rc, COLORREF bg, const wchar_t* txt)
{
    HBRUSH br = CreateSolidBrush(bg);
    FillRect(hdc, &rc, br);
    DeleteObject(br);

    SetBkMode(hdc, TRANSPARENT);
    SetTextColor(hdc, CLR_TEXT);
    DrawTextW(hdc, txt, -1, &rc, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
}

// -------------------------------------------------------------
// File selection
// -------------------------------------------------------------
std::wstring BrowseFile(bool save)
{
    wchar_t fileBuf[MAX_PATH] = L"";
    OPENFILENAMEW ofn = { sizeof(ofn) };
    ofn.hwndOwner = NULL;
    ofn.lpstrFile = fileBuf;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrFilter = L"All Files\0*.*\0";
    ofn.Flags = OFN_EXPLORER;

    if (save) {
        if (!GetSaveFileNameW(&ofn)) return L"";
    } else {
        if (!GetOpenFileNameW(&ofn)) return L"";
    }

    return fileBuf;
}

// -------------------------------------------------------------
// Thread-safe log append
// -------------------------------------------------------------
void Log(const std::wstring& msg)
{
    SendMessageW(hLog, EM_SETSEL, -1, -1);
    SendMessageW(hLog, EM_REPLACESEL, FALSE, (LPARAM)msg.c_str());
    SendMessageW(hLog, EM_SCROLLCARET, 0, 0);
}

// -------------------------------------------------------------
// Compression thread
// -------------------------------------------------------------
void StartCompression()
{
    wchar_t inBuf[MAX_PATH], outBuf[MAX_PATH], frameBuf[32], lvlBuf[16], thBuf[16];

    GetWindowTextW(hInput, inBuf, MAX_PATH);
    GetWindowTextW(hOutput, outBuf, MAX_PATH);
    GetWindowTextW(hFrameBytes, frameBuf, 32);
    GetWindowTextW(hLevel, lvlBuf, 16);
    GetWindowTextW(hThreads, thBuf, 16);

    bool recursive = SendMessageW(hChkRecursive, BM_GETCHECK, 0, 0) == BST_CHECKED;
    bool delSrc    = SendMessageW(hChkDelete,    BM_GETCHECK, 0, 0) == BST_CHECKED;
    bool batchMode = SendMessageW(hChkBatch,     BM_GETCHECK, 0, 0) == BST_CHECKED;
    bool decompress= SendMessageW(hChkDecompress,BM_GETCHECK, 0, 0) == BST_CHECKED;

    CompressionSettings cfg{};
    cfg.input_path      = inBuf;
    cfg.output_path     = outBuf;
    cfg.batch_mode      = batchMode;
    cfg.recursive       = recursive;
    cfg.delete_source   = delSrc;
    cfg.decompress_mode = decompress;
    cfg.frame_bytes     = _wtoi(frameBuf);
    cfg.level           = _wtoi(lvlBuf);
    cfg.threads         = _wtoi(thBuf);

    Log(L"Starting job...\r\n");

    try {
        run_compression_job(cfg, [&](const std::string& s){
            Log(std::wstring(s.begin(), s.end()));
        });
        Log(L"\r\nCompleted.\r\n");
    }
    catch (std::exception& e) {
        std::wstring w = L"[ERROR] ";
        w += std::wstring(e.what(), e.what()+strlen(e.what()));
        w += L"\r\n";
        Log(w);
    }
}

// -------------------------------------------------------------
// Window Procedure
// -------------------------------------------------------------
LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch(msg)
    {
    case WM_CTLCOLORDLG:
    case WM_CTLCOLORSTATIC:
        SetBkColor((HDC)wParam, CLR_BG);
        SetTextColor((HDC)wParam, CLR_TEXT);
        return (INT_PTR)CreateSolidBrush(CLR_BG);

    case WM_CTLCOLORBTN:
        SetBkColor((HDC)wParam, CLR_BTN);
        SetTextColor((HDC)wParam, CLR_TEXT);
        return (INT_PTR)CreateSolidBrush(CLR_BTN);

    case WM_CTLCOLORLISTBOX:
    case WM_CTLCOLOREDIT:
        SetBkColor((HDC)wParam, CLR_EDITBG);
        SetTextColor((HDC)wParam, CLR_TEXT);
        return (INT_PTR)CreateSolidBrush(CLR_EDITBG);

    case WM_COMMAND:
        switch(LOWORD(wParam))
        {
        case 1001: // Browse Input
        {
            auto f = BrowseFile(false);
            if (!f.empty())
                SetWindowTextW(hInput, f.c_str());
        }
        break;

        case 1002: // Browse Output
        {
            auto f = BrowseFile(true);
            if (!f.empty())
                SetWindowTextW(hOutput, f.c_str());
        }
        break;

        case 2001: // Start
            std::thread(StartCompression).detach();
            break;

        case 2002: // Clear
            SetWindowTextW(hLog, L"");
            break;
        }
        break;

    case WM_DESTROY:
        PostQuitMessage(0);
        break;
    }

    return DefWindowProcW(hwnd, msg, wParam, lParam);
}

// -------------------------------------------------------------
// WinMain
// -------------------------------------------------------------
int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE, PWSTR, int)
{
    InitCommonControls();

    g_font = CreateFontW(
        -16,0,0,0,FW_NORMAL,0,0,0,
        DEFAULT_CHARSET,0,0,0,0,
        L"Segoe UI"
    );

    WNDCLASSW wc{};
    wc.hbrBackground = CreateSolidBrush(CLR_BG);
    wc.hCursor = LoadCursor(NULL, IDC_ARROW);
    wc.hInstance = hInst;
    wc.lpfnWndProc = WndProc;
    wc.lpszClassName = L"Z3DS_GUI";

    RegisterClassW(&wc);

    HWND hwnd = CreateWindowExW(
        WS_EX_APPWINDOW,
        L"Z3DS_GUI", L"Z3DS Compressor GUI",
        WS_OVERLAPPEDWINDOW | WS_VISIBLE,
        CW_USEDEFAULT, CW_USEDEFAULT, 950, 600,
        NULL, NULL, hInst, NULL
    );

    // ---------------------------------------------------------
    // Create Controls (using better layout)
    // ---------------------------------------------------------
    hInput = CreateWindowW(L"EDIT", L"", WS_CHILD|WS_VISIBLE|WS_BORDER, 20,20,700,25, hwnd,0,0,0);
    hBrowseIn = CreateWindowW(L"BUTTON", L"Browse", WS_CHILD|WS_VISIBLE, 730,20,120,25, hwnd,(HMENU)1001,0,0);

    hOutput = CreateWindowW(L"EDIT", L"", WS_CHILD|WS_VISIBLE|WS_BORDER, 20,60,700,25, hwnd,0,0,0);
    hBrowseOut = CreateWindowW(L"BUTTON", L"Browse", WS_CHILD|WS_VISIBLE, 730,60,120,25, hwnd,(HMENU)1002,0,0);

    // Options
    hFrameBytes = CreateWindowW(L"EDIT", L"131072", WS_CHILD|WS_VISIBLE|WS_BORDER, 20,110,100,25, hwnd,0,0,0);
    hLevel      = CreateWindowW(L"EDIT", L"19", WS_CHILD|WS_VISIBLE|WS_BORDER, 140,110,60,25, hwnd,0,0,0);
    hThreads    = CreateWindowW(L"EDIT", L"0", WS_CHILD|WS_VISIBLE|WS_BORDER, 220,110,60,25, hwnd,0,0,0);

    hChkRecursive  = CreateWindowW(L"BUTTON", L"Recursive",  WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX, 320,110,120,25, hwnd,0,0,0);
    hChkBatch      = CreateWindowW(L"BUTTON", L"Batch mode", WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX, 450,110,120,25, hwnd,0,0,0);
    hChkDelete     = CreateWindowW(L"BUTTON", L"Delete source", WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX, 580,110,150,25, hwnd,0,0,0);
    hChkDecompress = CreateWindowW(L"BUTTON", L"Decompress", WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX, 740,110,120,25, hwnd,0,0,0);

    // Action Buttons
    hStartBtn = CreateWindowW(L"BUTTON", L"Start", WS_CHILD|WS_VISIBLE, 20,155,120,30, hwnd,(HMENU)2001,0,0);
    hClearBtn = CreateWindowW(L"BUTTON", L"Clear Log", WS_CHILD|WS_VISIBLE, 150,155,120,30, hwnd,(HMENU)2002,0,0);

    // Log box
    hLog = CreateWindowExW(WS_EX_CLIENTEDGE, L"EDIT", L"", 
        WS_CHILD|WS_VISIBLE|WS_VSCROLL|ES_MULTILINE|ES_AUTOVSCROLL|ES_READONLY,
        20,200,900,350,
        hwnd,0,0,0
    );

    // Apply font
    ApplyFont(hInput); ApplyFont(hOutput);
    ApplyFont(hFrameBytes); ApplyFont(hLevel); ApplyFont(hThreads);
    ApplyFont(hChkRecursive); ApplyFont(hChkBatch);
    ApplyFont(hChkDelete); ApplyFont(hChkDecompress);
    ApplyFont(hStartBtn); ApplyFont(hClearBtn);
    ApplyFont(hBrowseIn); ApplyFont(hBrowseOut);
    ApplyFont(hLog);

    MSG msg;
    while(GetMessageW(&msg, nullptr, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    return 0;
}
