@echo off
setlocal enabledelayedexpansion

echo ===============================================
echo  Z3DS Compressor - Zstd Folder Auto-Fixer
echo ===============================================

set ROOT=C:\Users\jacko\z3ds_compress_improvement_test
set ZSTDROOT=%ROOT%\external\zstd

echo Checking for Zstd folder at:
echo %ZSTDROOT%
echo.

if not exist "%ZSTDROOT%" (
    echo ERROR: external\zstd folder does not exist!
    pause
    exit /b 1
)

echo Searching for zstd.h inside external\zstd ...
for /r "%ZSTDROOT%" %%F in (zstd.h) do (
    set ZSTDFILE=%%F
    goto FOUND_ZSTD
)

echo ERROR: Could not find zstd.h anywhere inside external\zstd.
echo Make sure you extracted the Zstd *source* release.
pause
exit /b 1

:FOUND_ZSTD
echo Found zstd.h at:
echo %ZSTDFILE%
echo.

rem Expected location:
set EXPECTED=%ZSTDROOT%\lib\zstd.h

if /I "%ZSTDFILE%"=="%EXPECTED%" (
    echo Zstd is already in the correct location.
) else (
    echo Zstd is NOT in the correct location.
    echo Fixing folder layout...
    echo.

    rem Get parent folder of the found zstd.h
    for %%D in ("%ZSTDFILE%") do set ZSTDDIR=%%~dpD
    rem go up 1 level to the zstd root in the archive
    for %%P in ("%ZSTDDIR%..\..\") do set MOVEFROM=%%~fP

    echo Moving all Zstd source files from:
    echo %MOVEFROM%
    echo into:
    echo %ZSTDROOT%
    echo.

    xcopy "%MOVEFROM%\*" "%ZSTDROOT%\" /E /I /Y
)

echo.
echo Cleaning old CMake build directory...
rmdir /s /q "%ROOT%\build-msvc" 2>nul

echo.
echo Running CMake configure...
cd "%ROOT%"
cmake --preset windows-msvc
if errorlevel 1 (
    echo CMake configure failed!
    pause
    exit /b 1
)

echo.
echo Running CMake build (Release)...
cmake --build --preset windows-msvc-release
if errorlevel 1 (
    echo Build failed!
    pause
    exit /b 1
)

echo.
echo ===============================================
echo  BUILD SUCCESSFUL
echo  Executable located at:
echo  %ROOT%\build-msvc\Release\z3ds_gui.exe
echo ===============================================
pause
exit /b 0
